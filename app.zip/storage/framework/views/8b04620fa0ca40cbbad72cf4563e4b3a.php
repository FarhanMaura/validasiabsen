<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Data Kelas</h2>
                <p class="text-sm text-gray-600 mt-1">Kelola semua kelas dan informasi siswa</p>
            </div>
            <a href="<?php echo e(route('kelas.create')); ?>"
               class="bg-gradient-to-r from-[#1FAE59] to-green-500 hover:from-green-500 hover:to-green-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl flex items-center space-x-2">
                <i class="fas fa-plus text-sm"></i>
                <span>Tambah Kelas</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="mx-auto">
            <!-- Stats Overview -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <!-- Total Kelas -->
                <div class="bg-gradient-to-r from-[#1FAE59] to-green-500 rounded-2xl shadow-lg p-6 text-white">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-2xl font-bold"><?php echo e($kelas->total()); ?></p>
                            <p class="text-green-100 text-sm">Total Kelas</p>
                        </div>
                        <div class="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                            <i class="fas fa-door-open text-xl"></i>
                        </div>
                    </div>
                </div>

                <!-- Kelas X -->
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-2xl font-bold text-green-600"><?php echo e($kelas->where('tingkat', '10')->count()); ?></p>
                            <p class="text-gray-600 text-sm">Kelas X</p>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-1 text-green-600 text-xl"></i>
                        </div>
                    </div>
                </div>

                <!-- Kelas XI -->
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-2xl font-bold text-emerald-600"><?php echo e($kelas->where('tingkat', '11')->count()); ?></p>
                            <p class="text-gray-600 text-sm">Kelas XI</p>
                        </div>
                        <div class="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-2 text-emerald-600 text-xl"></i>
                        </div>
                    </div>
                </div>

                <!-- Kelas XII -->
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-2xl font-bold text-teal-600"><?php echo e($kelas->where('tingkat', '12')->count()); ?></p>
                            <p class="text-gray-600 text-sm">Kelas XII</p>
                        </div>
                        <div class="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-3 text-teal-600 text-xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Classes Grid -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <!-- Table Header -->
                <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-gray-900">Daftar Kelas</h3>
                        <div class="text-sm text-gray-600">
                            Total <?php echo e($kelas->total()); ?> kelas
                        </div>
                    </div>
                </div>

                <!-- Classes Cards for Mobile / Grid for Desktop -->
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-gradient-to-br from-white to-gray-50 rounded-2xl shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-2 group">
                            <!-- Class Header -->
                            <div class="p-6 border-b border-gray-200">
                                <div class="flex items-center justify-between mb-3">
                                    <div class="w-12 h-12 bg-gradient-to-r from-[#1FAE59] to-green-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                                        <span class="text-white font-bold text-lg"><?php echo e($item->tingkat); ?></span>
                                    </div>
                                    <div class="text-right">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                            <i class="fas fa-users mr-1 text-xs"></i>
                                            <?php echo e($item->siswas_count); ?>

                                        </span>
                                    </div>
                                </div>
                                <h4 class="text-xl font-bold text-gray-900 mb-1"><?php echo e($item->nama_kelas); ?></h4>
                                <p class="text-sm text-gray-600"><?php echo e($item->jurusan); ?></p>
                            </div>

                            <!-- Class Info -->
                            <div class="p-6">
                                <div class="space-y-3">
                                    <div class="flex items-center justify-between text-sm">
                                        <span class="text-gray-600 flex items-center">
                                            <i class="fas fa-graduation-cap text-gray-400 mr-2"></i>
                                            Tingkat
                                        </span>
                                        <span class="font-medium text-gray-900">Kelas <?php echo e($item->tingkat); ?></span>
                                    </div>

                                    <div class="flex items-center justify-between text-sm">
                                        <span class="text-gray-600 flex items-center">
                                            <i class="fas fa-book text-gray-400 mr-2"></i>
                                            Jurusan
                                        </span>
                                        <span class="font-medium text-gray-900"><?php echo e($item->jurusan); ?></span>
                                    </div>

                                    <div class="flex items-center justify-between text-sm">
                                        <span class="text-gray-600 flex items-center">
                                            <i class="fas fa-user-graduate text-gray-400 mr-2"></i>
                                            Siswa
                                        </span>
                                        <span class="font-medium text-gray-900"><?php echo e($item->siswas_count); ?> orang</span>
                                    </div>
                                </div>

                                <!-- Actions -->
                                <div class="mt-4 pt-4 border-t border-gray-200 flex justify-between">
                                    <a href="<?php echo e(route('kelas.show', $item)); ?>"
                                       class="text-green-600 hover:text-green-800 transition-colors duration-200 flex items-center text-sm font-medium">
                                        <i class="fas fa-eye mr-1"></i>
                                        Detail
                                    </a>
                                    <div class="flex space-x-2">
                                        <a href="<?php echo e(route('kelas.edit', $item)); ?>"
                                           class="text-emerald-600 hover:text-emerald-800 transition-colors duration-200 p-1 rounded-lg hover:bg-emerald-50"
                                           title="Edit">
                                            <i class="fas fa-edit text-sm"></i>
                                        </a>
                                        <form action="<?php echo e(route('kelas.destroy', $item)); ?>" method="POST" class="inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kelas ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                    class="text-red-600 hover:text-red-800 transition-colors duration-200 p-1 rounded-lg hover:bg-red-50"
                                                    title="Hapus">
                                                <i class="fas fa-trash text-sm"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="md:col-span-2 lg:col-span-3 xl:col-span-4">
                            <div class="text-center py-12">
                                <div class="text-gray-400 mb-4">
                                    <i class="fas fa-door-open text-6xl"></i>
                                </div>
                                <h4 class="text-lg font-semibold text-gray-900 mb-2">Belum Ada Kelas</h4>
                                <p class="text-gray-600 mb-6">Mulai dengan membuat kelas pertama Anda</p>
                                <a href="<?php echo e(route('kelas.create')); ?>"
                                   class="bg-gradient-to-r from-[#1FAE59] to-green-500 hover:from-green-500 hover:to-green-600 text-white px-6 py-3 rounded-xl text-sm font-medium transition-all duration-200 transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl inline-flex items-center space-x-2">
                                    <i class="fas fa-plus"></i>
                                    <span>Tambah Kelas Pertama</span>
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Pagination -->
                <?php if($kelas->hasPages()): ?>
                <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                    <div class="flex items-center justify-between">
                        <div class="text-sm text-gray-700">
                            Menampilkan <?php echo e($kelas->firstItem()); ?> hingga <?php echo e($kelas->lastItem()); ?> dari <?php echo e($kelas->total()); ?> kelas
                        </div>
                        <div class="flex space-x-2">
                            <?php echo e($kelas->links()); ?>

                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Quick Stats -->
            <div class="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-chart-bar text-green-600"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Rata-rata Siswa per Kelas</p>
                            <p class="text-lg font-bold text-gray-900">
                                <?php
                                    $totalSiswa = $kelas->sum('siswas_count');
                                    $avgSiswa = $kelas->count() > 0 ? round($totalSiswa / $kelas->count(), 1) : 0;
                                ?>
                                <?php echo e($avgSiswa); ?> siswa
                            </p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-users text-emerald-600"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Total Seluruh Siswa</p>
                            <p class="text-lg font-bold text-gray-900"><?php echo e($totalSiswa); ?> siswa</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-teal-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-star text-teal-600"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Kelas Terbanyak</p>
                            <p class="text-lg font-bold text-gray-900">
                                <?php
                                    $mostStudents = $kelas->sortByDesc('siswas_count')->first();
                                ?>
                                <?php echo e($mostStudents ? $mostStudents->nama_kelas : '-'); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 4px;
        }

        .pagination li a,
        .pagination li span {
            display: inline-block;
            padding: 8px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .pagination li a {
            color: #6B7280;
            background: white;
            border: 1px solid #E5E7EB;
        }

        .pagination li a:hover {
            background: #F3F4F6;
            border-color: #D1D5DB;
        }

        .pagination li span {
            color: #374151;
            background: #F3F4F6;
            border: 1px solid #D1D5DB;
        }

        .pagination li.active span {
            background: #1FAE59;
            color: white;
            border-color: #1FAE59;
        }

        .class-card {
            transition: all 0.3s ease;
        }

        .class-card:hover {
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\arifg\Documents\validasiabsen\resources\views/kelas/index.blade.php ENDPATH**/ ?>